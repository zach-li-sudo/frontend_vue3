<template>
  <BlogHeader/>
  <div class="container">
    <div class="page-header">
      <br><br>
    </div>

    <div style="text-align: center; margin: 0 auto; width:150px; height:150px; border-radius:50%; overflow:hidden;">
      <img alt src="https://elasticbeanstalk-us-east-2-737129357942.s3.us-east-2.amazonaws.com/sb.c13ba6d3.png">
    </div>
    <br>
    <h1 style="text-align: center;"><strong>Zach (Zhuo) Li </strong></h1>
    <li style="text-align: center; list-style-type: none;">
      <strong>Software Engineer and Developer</strong>
    </li>
    <li style="text-align: center; list-style-type: none;">
      School of Data Science
    </li>
    <li style="text-align: center; list-style-type: none;">
      the Chinese University of Hong Kong, Shenzhen, China
    </li>
    <li style="text-align: center; list-style-type: none;">
      Computational Mathematics, Optimization and Machine Learning
    </li>
    <li style="text-align: center; list-style-type: none;">
    </li>
    <br>
    <li style="text-align: center; list-style-type: none;">
<!--        <a style="text-decoration: none;" href="mailto:zhuo.li.ca@icloud.com">Contact me:</a>-->
    <strong style="padding-bottom: 0">Contact me:</strong>
    <br><br>
    <p style="text-align: center; height: 20px; width: auto">
      <a href="mailto:zhuo.li.ca@icloud.com" target="_blank"><img class="icons" src="https://elasticbeanstalk-us-east-2-737129357942.s3.us-east-2.amazonaws.com/email-4096.43194a11.png"></a>
      <a href="https://github.com/zach-li-sudo" target="_blank"><img class="icons github" src="../assets/github-icon.svg"></a>
      <a href="https://www.linkedin.com/in/zhuo-li-a80056171" target="_blank"><img class="icons" src="../assets/linkedin.png"></a>
    </p>
    </li>
  <br>
  <hr>

<h2 style="text-align: left;"><strong>Professional Experience</strong></h2>
<li style="list-style-type: circle;">
  <strong>Teaching Assistant</strong>, Chinese University of Hong Kong, Shenzhen, China
</li>
<ol>
  <li style="list-style-type: disc;">
      MAT3007 Optimization
  </li>
</ol>
<li style="list-style-type: circle;">
  <strong>Software Engineer (Robotics)</strong>, Chinese University of Hong Kong, Shenzhen, China
</li>
<ol>
  <li style="list-style-type: disc;">
      Accomplished multi-robot pathfinding software for industrial warehouses with around 10% of efficiency improvements in items pickup & delivery tasks (demo video below)
  </li>
  <div class="container my-4">
    <div class="row">
      <div class="col">
        <p>YouTube (International)</p>
        <div class="embed-responsive embed-responsive-16by9">
        <iframe class="embed-responsive-item" src="https://www.youtube.com/embed/3XO2v8r84CQ" allowfullscreen></iframe>
      </div>
      </div>
      <div class="col">
        <p>BiliBili (China)</p>
        <div class="embed-responsive embed-responsive-16by9">
          <iframe style="position: absolute; width: 100%; height: 100%; left: 0; top: 0;" src="https://player.bilibili.com/player.html?aid=765852474&;bvid=BV1gr4y1e7YD&cid=487797567&page=1&as_wide=1&high_quality=1&danmaku=0" frameborder="no" scrolling="no" allowfullscreen="true"></iframe>
  <!--      <iframe src="//player.bilibili.com/player.html?aid=765852474&bvid=BV1gr4y1e7YD&cid=487797567&page=1" scrolling="no" border="0" frameborder="no" framespacing="0" allowfullscreen="true"> </iframe>-->
        </div>
      </div>
    </div>
    <br>
  </div>
  <li style="list-style-type: disc;">
Contributed 6000+ lines of Python code for the algorithm prototype, manage the code repo on GitHub and write API documentation
  </li>
  <li style="list-style-type: disc;">
Developed a novel warehouse traffic prediction module by using <img src="https://latex.codecogs.com/svg.image?L_1-L_2" title="L_1-L_2" /> norm mathematical optimization techniques (Lasso regression) in PyTorch
  </li>
  <li style="list-style-type: disc;">
Reduced the computational cost of traffic prediction to an affordable level, 8-10 seconds on entry-level CPUs (150+ seconds in the previous version)
  </li>
  <li style="list-style-type: disc;">
Redesigned the conflict resolution mechanism to make the pathfinding algorithm collision & deadlock-free
  </li>

</ol>
<li style="list-style-type: circle;">
  <strong>Engineer - Intern</strong>, Motus Design Group, Victoria, Canada
</li>
<ol>
  <li style="list-style-type: disc;">
      Succeeded an extended Kalman filter algorithm, which is fast enough for real-time implementation, to estimate cycling parameters from noisy data sources.
  </li>
  <li style="list-style-type: disc;">
      Develop a statistical model to fit critical power data and the associated model parameter detecting algorithm by using accelerated gradient descent methods
  </li>
  <li style="list-style-type: disc;">
      Design a model validation module with 95% confidence bounds by using Gaussian process regression
  </li>
  <li style="list-style-type: disc;">
      Contribute the algorithms and code to a patent named modular aerodynamic sensor system for cycling (coming soon) for the company
  </li>
</ol>

    <h2 style="text-align: left;"><strong>Skills</strong></h2>
    <li style="list-style-type: circle;"><strong>Algorithm Prototyping:</strong></li>
  <ol>
    <li style="list-style-type: disc;">
      Programming Languages: Python, JavaScript, C/C++, Julia, MATLAB
    </li>
    <li style="list-style-type: disc;">
      Computational Mathematics: cvxopt, sedumi, gurobi, yalmip
    </li>
    <li style="list-style-type: disc;">
      Machine Learning/Data Processing: PyTorch, sk-learn, NumPy, Pandas, etc
    </li>

  </ol>
    <li style="list-style-type: circle;"><strong>Software Developing:</strong></li>
  <ol>
    <li style="list-style-type: disc;">
      Backend: Python Django, REST API with JSON feeds, Django-Rest-Framework, PostgreSQL, AWS Relational Database Service
    </li>
    <li style="list-style-type: disc;">
      Frontend: HTML/CSS/JavaScript, Vue.js, Bootstrap, Parcel.js, webpack.js
    </li>
    <li style="list-style-type: disc;">
      Dev/Test/Deploy: Frontend-Backend Separation, Postman API Testing Automation, AWS Elastic Beanstalk/RDS/S3, Docker Container.
    </li>
    <li style="list-style-type: disc;">
      Operating Systems: Linux CLIs, MacOS zsh, Windows PowerShell
    </li>
    <li style="list-style-type: disc;">
      Linux/Unix Skills: CLIs, bash, ssh, remote developing
    </li>
    <li style="list-style-type: disc;">
      Version Control: git
    </li>
    <li style="list-style-type: disc;">
      Documenting/Presentation: LaTeX, Markdown, Microsoft office
    </li>
  </ol>


<li style="list-style-type: circle;">
  <strong>Teaching Assistant</strong>, University of Victoria, Victoria, Canada
</li>
<ol>
  <li style="list-style-type: disc;">
      Offer tutorials, help undergrads with C/C++ microcontroller programming experiments and answer assignment questions in 3 different courses (Mechatronics, Robotics, Control Engineering)
  </li>
    <li style="list-style-type: disc;">
      Help students with their projects: (demo video below)
      <div class="container my-4">
    <div class="row">
      <div class="col">
        <p>YouTube (International)</p>
        <div class="embed-responsive embed-responsive-16by9">
        <iframe class="embed-responsive-item" src="https://www.youtube.com/embed/qAaNMidDf4s" allowfullscreen></iframe>
        </div>
      </div>
    </div>
    <br>
  </div>
  </li>
</ol>

<h2 style="text-align: left;"><strong>Publication</strong></h2>
<li style="list-style-type: circle;">
  MAS consensus
</li>
<ol>
  <li style="list-style-type: disc;">
      (Suspended) PhD in Data Science
  </li>
</ol>

<h2 style="text-align: left;"><strong>Education</strong></h2>
<li style="list-style-type: circle;">
  <strong>Chinese University of Hong Kong, Shenzhen, China</strong>
</li>
<ol>
  <li style="list-style-type: disc;">
      (Suspended) PhD in Data Science, Mathematical Optimization and Machine Learning
  </li>
</ol>
<li style="list-style-type: circle;">
  <strong>University of Victoria, Canada</strong>
</li>
<ol>

  <li style="list-style-type: disc;">
      Master of Applied Science, Optimization and Control Theory
  </li>
  <li style="list-style-type: disc;">
      GPA:9.0/9.0
  </li>
</ol>
<li style="list-style-type: circle;">
  <strong>Northwestern Polytechnical University, Xi'an, China</strong>
</li>
<ol>
  <li style="list-style-type: disc;">
      Bachelor of Engineering, Electrics and Electronics
  </li>
  <li style="list-style-type: disc;">
      GPA:89.26/100
  </li>
</ol>
</div>

  <br><br><br><br><br><br>
  <BlogFooter/>
</template>

<script>
  import BlogHeader from '@/components/BlogHeader.vue'
  import BlogFooter from '@/components/BlogFooter.vue'
export default {
  name: "AboutPage",
  components: {BlogHeader, BlogFooter},
  // data() {
  //   return {
  //     imgProfile: "https://elasticbeanstalk-us-east-2-737129357942.s3.us-east-2.amazonaws.com/sb.c13ba6d3.png",
  //     imgMail: "https://elasticbeanstalk-us-east-2-737129357942.s3.us-east-2.amazonaws.com/email-4096.43194a11.png",
  //     imgGithub: "https://elasticbeanstalk-us-east-2-737129357942.s3.us-east-2.amazonaws.com/github-icon.2b2a2e4f.svg",
  //     imgLinkedIn: "",
  //   }
  // }
}
</script>

<style scoped>

 .icons {
   height: 35px;
   width: auto;
   margin-left: 5px;
   margin-right: 5px;
   border-radius: 50%;
 }

   .icons:hover {
    -o-transition:.3s;
    -ms-transition:.3s;
    -moz-transition:.3s;
    -webkit-transition:.3s;
    transition:.3s;
    box-shadow: 5px 5px 5px #888888;
   border-color: dimgray;
  }


 .github {
   height: 40px;
 }
</style>