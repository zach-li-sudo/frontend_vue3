<template>

</template>

<script>
export default {
  name: "TyporaHTML"
}
</script>

<style scoped>

</style>