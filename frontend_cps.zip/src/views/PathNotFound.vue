<template>
  <BlogHeader></BlogHeader>
  <br>
  <div class="container" style="text-align: center">
    <div class="row">
        <div class="col-md-12">
            <div class="error-template">
                <h1>
                    Oops!</h1>
                <h2>
                    404 Not Found</h2>
                <div class="error-details">
                    Sorry, an error has occured, Requested page not found!
                </div>
                <div class="error-actions">
                  <br>
                    <a href="/" class="btn btn-primary btn-lg"><span class="glyphicon glyphicon-home"></span>
                      Take Me Home
                    </a>
                </div>
                </div>
            </div>
        </div>
    </div>
  <BlogFooter></BlogFooter>
</template>

<script>
import BlogHeader from "@/components/BlogHeader";
import BlogFooter from "@/components/BlogFooter";
export default {
  name: "PathNotFound",
  components: {BlogFooter, BlogHeader}
}
</script>

<style scoped>

</style>