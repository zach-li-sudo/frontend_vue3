<template>
    <BlogHeader/>
    <div id="article-create">
        <h3>Publish Article</h3>

        <form id="image_form">
            <div class="form-elem">
                <span>Profile：</span>
                <input
                        v-on:change="onFileChange"
                        type="file"
                        id="file"
                >
            </div>
        </form>
        <form>
            <div class="form-elem">
                <span>Title：</span>
                <input v-model="title" type="text" placeholder="Enter title">
            </div>

            <div class="form-elem">
                <span>Category：</span>
                <span
                        v-for="category in categories"
                        :key="category.id"
                >
                    <button
                            class="category-btn"
                            :style="categoryStyle(category)"
                            @click.prevent="chooseCategory(category)"
                    >
                        {{category.title}}
                    </button>
                </span>
            </div>

            <div class="form-elem">
                <span>Tags：</span>
                <input v-model="tags" type="text" placeholder="Enter tags">
            </div>

            <div class="form-elem">
                <span>Body：</span>
                <textarea v-model="body" placeholder="Your article" rows="20" cols="80"></textarea>
            </div>

            <div class="form-elem">
                <button v-on:click.prevent="submit">Submit</button>
            </div>
        </form>
    </div>
    <BlogFooter/>
</template>

<script>
    import BlogHeader from '@/components/BlogHeader.vue'
    import BlogFooter from '@/components/BlogFooter.vue'
    import axios from 'axios';
    import authorization from '@/utils/authorization';

    export default {
        name: 'ArticleCreate',
        components: {BlogHeader, BlogFooter},
        data: function () {
            return {
                title: '',
                body: '',
               categories: [],
                selectedCategory: null,
                tags: '',
               avatarID: null,
            }
        },
        mounted() {
            axios
                .get('/api/category/')
                .then(response => this.categories = response.data)
        },
        methods: {
            onFileChange(e) {
                const file = e.target.files[0];
                // this.imageUrl = URL.createObjectURL(file);

                let formData = new FormData();
                formData.append("content", file);

                axios
                    .post('/api/avatar/', formData, {
                        headers: {
                            'Content-Type': 'multipart/form-data',
                            'Authorization': 'Bearer ' + localStorage.getItem('access.myblog')
                        }
                    })
                    .then( response => this.avatarID = response.data.id)
            },
            categoryStyle(category) {
                if (this.selectedCategory !== null && category.id === this.selectedCategory.id) {
                    return {
                        backgroundColor: 'black',
                    }
                }
                return {
                    backgroundColor: 'lightgrey',
                    color: 'black',
                }
            },
            chooseCategory(category) {
                if (this.selectedCategory !== null && this.selectedCategory.id === category.id) {
                    this.selectedCategory = null
                }
                else {
                    this.selectedCategory = category;
                }
            },
            submit() {
                const that = this;
                authorization()
                    .then(function (response) {
                            if (response[0]) {

                                let data = {
                                    title: that.title,
                                    body: that.body,
                                };

                                data.avatar_id = that.avatarID;

                                if (that.selectedCategory) {
                                    data.category_id = that.selectedCategory.id
                                }
                                data.tags = that.tags
                                    .split(/[,，]/)
                                    .map(x => x.trim())
                                    .filter(x => x.charAt(0) !== '');

                                const token = localStorage.getItem('access.myblog');
                                axios
                                    .post('/api/article/',
                                        data,
                                        {
                                            headers: {Authorization: 'Bearer ' + token}
                                        })
                                    .then(function (response) {
                                        that.$router.push({name: 'ArticleDetail', params: {id: response.data.id}});
                                    })
                            }
                            else {
                                alert('Session expired. Please login again.')
                            }
                        }
                    )
            }
        }
    }
</script>

<style scoped>

    .category-btn {
        margin-right: 10px;
    }

    #article-create {
        text-align: center;
        font-size: large;
    }

    form {
        text-align: left;
        padding-left: 100px;
        padding-right: 10px;
    }

    .form-elem {
        padding: 10px;
    }

    input {
        height: 25px;
        padding-left: 10px;
        width: 50%;
    }

    button {
        height: 35px;
        cursor: pointer;
        border: none;
        outline: none;
        background: steelblue;
        color: whitesmoke;
        border-radius: 5px;
        width: 60px;
    }
</style>