<template>
  <br>
  <div id="footer">
    <hr>
    <a class="address" href="/">zach-z-li.ca</a>
    <p class="logos">
      Made with
      <a href="https://www.python.org/" target="_blank">
        <img class="python-logo" src="https://elasticbeanstalk-us-east-2-737129357942.s3.us-east-2.amazonaws.com/python-logo-png.1eb04e93.png" alt="python">
<!--        <img src="./static/img/python-logo-png.png" class="python-logo" alt="python">-->
      </a>
      <a href="https://www.djangoproject.com/" target="_blank">
        <img class="django-logo" src="https://elasticbeanstalk-us-east-2-737129357942.s3.us-east-2.amazonaws.com/django-icon.02711c2c.jpg" alt="django">
      </a>
      <a href="https://www.javascript.com/" target="_blank">
        <img class="js-logo" src='@/assets/js-logo.jpeg' alt="js">
      </a>
      <a href="https://vuejs.org/" target="_blank">
        <img class="vue-logo" src="https://elasticbeanstalk-us-east-2-737129357942.s3.us-east-2.amazonaws.com/vue-logo-circle.9f76f686.png" alt="vue">
      </a>

      Hosted on
      <a href="https://aws.amazon.com/" target="_blank">
        <img src="https://elasticbeanstalk-us-east-2-737129357942.s3.us-east-2.amazonaws.com/aws-logo.a7e17535.png" class="aws-logo" alt="aws">
      </a>
      <a href="https://www.docker.com/" target="_blank">
        <img src="@/assets/docker-logo.png" alt="docker" class="docker-logo">
      </a>
    </p>
  </div>
</template>

<script>
  export default {
    name: 'BlogFooter',
    // data() {
    //   return {
    //     imgPythonLogo: "https://elasticbeanstalk-us-east-2-737129357942.s3.us-east-2.amazonaws.com/python-logo-png.1eb04e93.png",
    //     imgDjangoLogo: require('./../assets/django-icon.jpg'),
    //     imgJavaScriptLogo: require('@/assets/js-logo.jpeg'),
    //     imgVueLogo: require('../assets/vue-logo-circle.png'),
    //   };
    // }
  }
</script>

<style scoped>
  img {
    width: 30px;
    height: auto;
    border-radius: 50%;
  }

  img:hover {
    -o-transition:.3s;
    -ms-transition:.3s;
    -moz-transition:.3s;
    -webkit-transition:.3s;
    transition:.3s;
    box-shadow: 5px 5px 5px #888888;
  }

  .docker-logo {
    margin-left: 5px;
    border-radius: 50%;
  }

  .aws-logo {
    border-radius: 50%;
  }

  .js-logo {
    border-radius: 35px;
  }

  .vue-logo {
    border-radius: 25px;
  }

  #footer {
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, "Noto Sans", "Liberation Sans", sans-serif, "Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol", "Noto Color Emoji";
    position: fixed;
    left: 0;
    bottom: 0;
    height: 100px;
    width: 100%;
    background: whitesmoke;
    text-align: center;
    padding-bottom: 20px;
    box-shadow: 2px 0 0 dimgray;
  }

  .address {
    text-decoration: none;
    font-weight: bold;
    font-size: 20px;
    /*position: absolute;*/
    /*top: 25%;*/
    color: #262626;
  }

  .address:hover,
  .address:active {
    text-decoration: red;
  }
</style>