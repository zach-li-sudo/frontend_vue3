<template>
  <br>
  <br>
  <hr>
    <h3>Comments</h3>
  <br>
  <input
      class="form-control"
      type="text"
      placeholder="Comment block with third-party login is under construction"
      size="40"
      readonly>
</template>

<script>
export default {
  name: "ThridPartyComments"
}
</script>

<style scoped>
  .form-control {
    margin-bottom: 220px;
  }
  .form-control:hover {
    cursor: not-allowed;
  }
</style>