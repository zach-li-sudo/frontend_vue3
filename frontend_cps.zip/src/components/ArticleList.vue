<template>
  <div class="container">
    <div class="article-list-div">
      <div>
        <br>
      </div>
        <div v-if="info.count == 0">
          No matches are found, please try other keywords.<br><br>
        </div>

        <div v-for="article in info.results" v-bind:key="article.url" id="articles">
<!--            <p>DDDD {{ info.count }}</p>-->
            <div class="grid" :style="gridStyle(article)">
          <div class="image-container">
              <img :src="imageIfExists(article)" alt="" class="image">
          </div>

          <div>
            <div>
              <span v-if="article.category !== null" class="category">
                {{article.category.title}}
              </span>
              <span v-for="tag in article.tags" v-bind:key="tag" class="tag">
                {{ tag }}
              </span>
            </div>
            <div class="a-title-container">
                <router-link
                  :to="{ name: 'ArticleDetail', params: { id: article.id }}"
                  class="article-title"
                >
                  {{ article.title }}
                </router-link>
              </div>
              <div>Created on {{ formatted_time(article.created) }}</div>
            </div>
        </div>
      </div>

<!--      <div id="paginator">-->
<!--        <span v-if="is_page_exists('previous')">-->
<!--          <router-link :to="get_path('previous')">-->
<!--            Back-->
<!--          </router-link>-->
<!--        </span>-->
<!--        <span class="current-page">-->
<!--          {{ get_page_param('current') }}-->
<!--        </span>-->
<!--        <span v-if="is_page_exists('next')">-->
<!--          <router-link :to="get_path('next')">-->
<!--            Next-->
<!--          </router-link>-->
<!--        </span>-->
<!--      </div>-->

      <nav aria-label="Page navigation example">
        <ul class="pagination justify-content-center">
          <li v-if="is_page_exists('previous')" class="page-item ">
            <router-link class="page-link" :to="get_path('previous')">
            Previous
            </router-link>
          </li>
          <li v-else class="page-item disabled">
            <router-link class="page-link" :to="get_path('previous')">
            Previous
            </router-link>
          </li>

          <li v-if="get_page_param('current')" class="page-item"><div class="page-link page-number">{{ get_page_param('current') }}</div></li>
          <li v-else class="page-item"><div class="page-link page-number">1</div></li>

          <li v-if="is_page_exists('next')" class="page-item ">
            <router-link class="page-link" :to="get_path('next')">
            Next
            </router-link>
          </li>
          <li v-else class="page-item disabled">
            <router-link class="page-link" :to="get_path('next')">
            Next
            </router-link>
          </li>
        </ul>
      </nav>

    </div>
  </div>
</template>

<script>
  // import Home from "@/views/Home";
  import {ref} from 'vue'
    import {useRoute} from 'vue-router'
    import getArticleData from '@/composables/getArticleData.js'
    import pagination from '@/composables/pagination.js'
    import articleGrid from '@/composables/articleGrid.js'
    import formattedTime from '@/composables/formattedTime.js'


    export default {
      name: 'ArticleList',
      setup() {
        const info = ref('');
        const route = useRoute();

        const kwargs = ref({page: 0, searchText: ''});
        getArticleData(info, route, kwargs);

        const {
          is_page_exists,
          get_page_param,
          get_path
        } = pagination(info, route);

        const {
          imageIfExists,
          gridStyle
        } = articleGrid();

        const formatted_time = formattedTime;

        return {
          info,
          is_page_exists,
          get_page_param,
          get_path,
          imageIfExists,
          gridStyle,
          formatted_time,
        }
      },
  }
</script>

<style scoped>


#articles {
  margin-bottom: 1rem;
  margin-left: 1rem;
  margin-right: 1rem;
  border-radius: 10px;
  padding: 10px;
  height: 100%;
}

#articles:hover {
  box-shadow: 4px 4px 4px 4px #ccc;
  transform: scale(1.01);
  transition-delay: 0.2s;
  transition: box-shadow 0.2s ease;
}

nav {
  display: flex;
  position: relative;
  margin: 0 auto;
  float: bottom;
  height: 100%;
}

.disabled {
  cursor: not-allowed;
}

.pagination {
  margin-bottom: 50px;
}

.page-number {
  color: black;
}
.image {
    width: 180px;
    border-radius: 10px;
    box-shadow: darkslategrey 0 0 12px;
  }

  .image-container {
    width: 200px;
  }

  .grid {
    padding-bottom: 10px;
  }

  .article-title {
    font-size: large;
    font-weight: bolder;
    color: black;
    text-decoration: none;
  }

  .a-title-container {
    padding: 5px 0 5px 0;
  }

  .category {
    padding: 5px 10px 5px 10px;
    margin: 5px 5px 5px 0;
    font-family: Georgia, Arial, sans-serif;
    font-size: small;
    background-color: darkred;
    color: whitesmoke;
    border-radius: 15px;

  }

  .tag {
    padding: 2px 5px 2px 5px;
    margin: 5px 5px 5px 0;
    font-family: Georgia, Arial, sans-serif;
    font-size: small;
    background-color: #4e4e4e;
    color: whitesmoke;
    border-radius: 5px;
  }

  a {
    color: black;
  }

.article-list-div {
  display: flex;
  flex-flow: column;
  height: 100%;
  overflow: auto;
  margin-bottom: 70px;
}
</style>
