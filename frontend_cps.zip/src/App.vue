<template>
<!--  <router-view/>-->
 <div id="app">
  <router-view/>
 </div>

</template>

<script>
  export default {
    name: 'App',

  };
</script>

<style>
  #app {
    font-family: Georgia, Arial, sans-serif;
    margin-left: 0;
    margin-right: 0;
    position: relative;
    float: bottom;
    height: 90vh;
    width: 100vw;
  }
</style>
