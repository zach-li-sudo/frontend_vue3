import {createApp} from 'vue'
import App from './App.vue'
import router from './router'
import "bootstrap/dist/css/bootstrap.min.css"

// code highlight package
import hljs from "highlight.js";
import 'highlight.js/styles/monokai.css'
//
// // Katex for math equation rendering
// import katex from "katex";
// import 'katex/dist/katex.css'
// import renderMathInElement from "katex/contrib/auto-render";
//
// const renderOption = {
//   delimiters: [
//     {left: '$$', right: '$$', display: true},
//     {left: '$', right: '$', display: false},
//     {left: '\\(', right: '\\)', display: false},
//     {left: '\\[', right: '\\]', display: true}
//   ],
//   throwOnError : false
// }

URLSearchParams.prototype.appendIfExists = function (key, value) {
    if (value !== null && value !== undefined) {
        this.append(key, value)
    }
};

const app = createApp(App);

app.use(router);
app.mount('#app');

app.directive('highlight',function (el) {
  let highlight = el.querySelectorAll('pre code');
  highlight.forEach((block)=>{
      hljs.highlightBlock(block)
  })
});