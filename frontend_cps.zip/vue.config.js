module.exports = {
    runtimeCompiler: true,
  //   configureWebpack: {
  //   resolve: {
  //     alias: {
  //       'balm-ui-plus': 'balm-ui/dist/balm-ui-plus.js',
  //       'balm-ui-css': 'balm-ui/dist/balm-ui.css'
  //     }
  //   }
  // },
    devServer: {
        proxy: {
            // detail: https://cli.vuejs.org/config/#devserver-proxy
            '/api': {
                target: `http://127.0.0.1:8000/api`,
                changeOrigin: true,
                pathRewrite: {
                    '^/api': ''
                }
            }
        },
    },
    publicPath: './',
    assetsDir: 'static',
};