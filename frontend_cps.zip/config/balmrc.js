module.exports = {
  styles: {
    extname: 'scss'
  }
  // Other Options...
};